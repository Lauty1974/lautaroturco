import sqlite3

# Crear / Conectar a la base de datos
conn = sqlite3.connect('empresa83.db')
cursor = conn.cursor()

# Crear tabla facturas
cursor.execute('''
CREATE TABLE IF NOT EXISTS facturas (
    nro_factura INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL
);
''')

# Crear tabla items
cursor.execute('''
CREATE TABLE IF NOT EXISTS items (
    nro_factura INTEGER,
    id_articulo INTEGER,
    precio REAL,
    PRIMARY KEY (nro_factura, id_articulo),
    FOREIGN KEY (nro_factura) REFERENCES facturas(nro_factura)
);
''')

# Poblar tabla facturas
cursor.execute("INSERT INTO facturas VALUES (1, 'Juan')")
cursor.execute("INSERT INTO facturas VALUES (2, 'Ana')")
cursor.execute("INSERT INTO facturas VALUES (3, 'Juan')")
cursor.execute("INSERT INTO facturas VALUES (4, 'Carlos')")

# Poblar tabla items
cursor.execute("INSERT INTO items VALUES (1, 101, 500.0)")
cursor.execute("INSERT INTO items VALUES (1, 102, 1500.0)")
cursor.execute("INSERT INTO items VALUES (2, 103, 700.0)")
cursor.execute("INSERT INTO items VALUES (3, 104, 200.0)")
cursor.execute("INSERT INTO items VALUES (3, 105, 300.0)")
cursor.execute("INSERT INTO items VALUES (4, 106, 1000.0)")

conn.commit()
conn.close()

print("Base de datos 'empresa83.db' creada y cargada correctamente.")
