import sqlite3

# Conexión a la base creada
conn = sqlite3.connect('empresa83.db')
cursor = conn.cursor()

# Pedir nombre del cliente
nombre_cliente = input("Ingrese el nombre del cliente: ")

# Consulta para obtener el promedio de los precios de sus facturas
cursor.execute('''
SELECT AVG(items.precio)
FROM facturas
JOIN items ON facturas.nro_factura = items.nro_factura
WHERE LOWER(facturas.nombre) = LOWER(?);
''', (nombre_cliente,))

resultado = cursor.fetchone()[0]

# Mostrar resultado
if resultado is not None:
    print(f"El promedio de los precios de las facturas de {nombre_cliente} es: {resultado:.2f}")
else:
    print(f"No se encontraron facturas para el cliente '{nombre_cliente}'.")

conn.close()
