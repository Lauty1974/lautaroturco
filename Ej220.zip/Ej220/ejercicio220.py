import sqlite3

conexion = sqlite3.connect("ventas.db")
cursor = conexion.cursor()

# a) Precio total de una máquina según lista de componentes
def precio_maquina():
    codigos = input("Ingrese códigos de artículos separados por coma (máx 5): ").split(",")
    codigos = [c.strip() for c in codigos if c.strip() != ""]
    placeholders = ",".join("?" * len(codigos))
    query = f"SELECT Descripcion, Precio FROM Articulos WHERE Codigo IN ({placeholders})"
    cursor.execute(query, codigos)
    total = 0
    print("\nComponentes:")
    for desc, precio in cursor.fetchall():
        print(f"{desc:30} ${precio}")
        total += precio
    print(f"\nPrecio total: ${total}\n")

# b) Cantidad de veces vendido cada componente
def cantidad_vendidos():
    query = """
    SELECT a.Descripcion, COUNT(v.CodigoArticulo) AS Cantidad
    FROM Articulos a
    LEFT JOIN Ventas v ON a.Codigo = v.CodigoArticulo
    GROUP BY a.Codigo
    """
    print("\nCantidad de veces vendido cada artículo:")
    for desc, cant in cursor.execute(query):
        print(f"{desc:30} {cant}")

# c) Vendedor que más vendió (en $) en un mes/año ingresado
def mejor_vendedor_mes():
    mes = input("Ingrese mes (MM): ")
    anio = input("Ingrese año (AAAA): ")
    query = f"""
    SELECT v.Nombre, SUM(a.Precio) AS Total
    FROM Ventas ve
    JOIN Vendedores v ON ve.CodigoVendedor = v.Codigo
    JOIN Articulos a ON ve.CodigoArticulo = a.Codigo
    WHERE strftime('%m', ve.Fecha) = ? AND strftime('%Y', ve.Fecha) = ?
    GROUP BY v.Nombre
    ORDER BY Total DESC
    LIMIT 1
    """
    cursor.execute(query, (mes, anio))
    fila = cursor.fetchone()
    if fila:
        print(f"\nEl mejor vendedor en {mes}/{anio} fue {fila[0]} con ${fila[1]:.2f}\n")
    else:
        print("\nNo hay ventas registradas en esa fecha.\n")

# d) Importe total en una fecha
def total_por_fecha():
    fecha = input("Ingrese fecha (dd-mm-aaaa): ")
    query = """
    SELECT SUM(a.Precio)
    FROM Ventas v JOIN Articulos a ON v.CodigoArticulo = a.Codigo
    WHERE v.Fecha = ?
    """
    cursor.execute(query, (fecha,))
    total = cursor.fetchone()[0]
    print(f"\nTotal vendido el {fecha}: ${total or 0}\n")

# e) Importe total de un mes
def total_por_mes():
    mes = input("Ingrese mes (MM): ")
    query = """
    SELECT SUM(a.Precio)
    FROM Ventas v JOIN Articulos a ON v.CodigoArticulo = a.Codigo
    WHERE strftime('%m', v.Fecha) = ?
    """
    cursor.execute(query, (mes,))
    total = cursor.fetchone()[0]
    print(f"\nTotal vendido en el mes {mes}: ${total or 0}\n")

# f) Total vendido por un vendedor (sin límite de fecha)
def total_por_vendedor():
    nombre = input("Ingrese nombre del vendedor: ")
    query = """
    SELECT SUM(a.Precio)
    FROM Ventas v
    JOIN Vendedores ve ON v.CodigoVendedor = ve.Codigo
    JOIN Articulos a ON v.CodigoArticulo = a.Codigo
    WHERE ve.Nombre = ?
    """
    cursor.execute(query, (nombre,))
    total = cursor.fetchone()[0]
    print(f"\nTotal vendido por {nombre}: ${total or 0}\n")

# --- Menú interactivo ---
while True:
    print("""
    a) Precio de máquina por componentes
    b) Cantidad de veces vendido cada componente
    c) Vendedor que más vendió en un mes
    d) Total de ventas en una fecha
    e) Total de ventas en un mes
    f) Total de ventas por vendedor
    x) Salir
    """)
    op = input("Elija opción: ").lower()
    if op == "a": precio_maquina()
    elif op == "b": cantidad_vendidos()
    elif op == "c": mejor_vendedor_mes()
    elif op == "d": total_por_fecha()
    elif op == "e": total_por_mes()
    elif op == "f": total_por_vendedor()
    elif op == "x": break
    else: print("Opción no válida.")
