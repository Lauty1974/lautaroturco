import sqlite3

# Crear base de datos
conexion = sqlite3.connect("ventas.db")
cursor = conexion.cursor()

# Crear tablas
cursor.executescript("""
DROP TABLE IF EXISTS Vendedores;
DROP TABLE IF EXISTS Articulos;
DROP TABLE IF EXISTS Ventas;

CREATE TABLE Vendedores (
    Codigo INTEGER PRIMARY KEY,
    Nombre TEXT
);

CREATE TABLE Articulos (
    Codigo INTEGER PRIMARY KEY,
    Descripcion TEXT,
    Precio REAL
);

CREATE TABLE Ventas (
    Fecha TEXT,
    CodigoVendedor INTEGER,
    CodigoArticulo INTEGER,
    NroFactura INTEGER,
    FOREIGN KEY (CodigoVendedor) REFERENCES Vendedores(Codigo),
    FOREIGN KEY (CodigoArticulo) REFERENCES Articulos(Codigo)
);
""")

# Insertar datos
cursor.executemany("INSERT INTO Vendedores VALUES (?,?)", [
    (1, 'Martín'),
    (2, 'Diego'),
    (3, 'Claudio'),
    (4, 'José')
])

cursor.executemany("INSERT INTO Articulos VALUES (?,?,?)", [
    (1, 'Monitor GPRS 3000', 200),
    (2, 'Motherboard ASUS 1500', 120),
    (3, 'Monitor ASC 543', 250),
    (4, 'Motherboard ASUS 1200', 100),
    (5, 'Motherboard Pindorcho', 30)
])

cursor.executemany("INSERT INTO Ventas VALUES (?,?,?,?)", [
    ('01-02-2014', 1, 1, 10),
    ('01-02-2014', 1, 2, 10),
    ('01-02-2014', 2, 3, 11),
    ('01-02-2014', 2, 5, 11),
    ('10-02-2014', 1, 3, 25),
    ('10-02-2014', 1, 4, 25),
    ('12-02-2014', 2, 1, 38),
    ('12-02-2014', 2, 4, 38),
    ('04-03-2014', 2, 1, 82),
    ('04-03-2014', 2, 2, 82)
])

conexion.commit()
conexion.close()

print("Base de datos creada correctamente.")
