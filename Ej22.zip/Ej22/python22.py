# ejercicio22.py
import sqlite3

# Conexión a la base de datos
conn = sqlite3.connect('escuela.db')
cursor = conn.cursor()

# Pedir el ID del profesor
try:
    id_profesor = int(input("Ingrese el ID del profesor a eliminar: "))
except ValueError:
    print("Error: debe ingresar un número entero.")
    conn.close()
    exit()

# Verificar si el profesor existe
cursor.execute("SELECT nombre FROM Profesores WHERE id = ?", (id_profesor,))
profesor = cursor.fetchone()

if not profesor:
    print(f"No existe ningún profesor con el ID {id_profesor}.")
else:
    nombre_prof = profesor[0]

    # Eliminar registros relacionados en Cursos_Materias
    cursor.execute("DELETE FROM Cursos_Materias WHERE id_profesor = ?", (id_profesor,))

    # Eliminar el profesor
    cursor.execute("DELETE FROM Profesores WHERE id = ?", (id_profesor,))

    conn.commit()
    print(f"Profesor '{nombre_prof}' (ID: {id_profesor}) eliminado correctamente, junto con sus registros relacionados.")

conn.close()
