# script22.py
import sqlite3

# Crear base de datos
conn = sqlite3.connect('escuela.db')
cursor = conn.cursor()

# Borrar tablas si existen
cursor.execute("DROP TABLE IF EXISTS Cursos_Materias")
cursor.execute("DROP TABLE IF EXISTS Profesores")

# Crear tabla Profesores
cursor.execute('''
CREATE TABLE Profesores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL
)
''')

# Crear tabla Cursos_Materias
cursor.execute('''
CREATE TABLE Cursos_Materias (
    id_curso INTEGER NOT NULL,
    id_materia INTEGER NOT NULL,
    id_profesor INTEGER NOT NULL,
    PRIMARY KEY (id_curso, id_materia, id_profesor),
    FOREIGN KEY (id_profesor) REFERENCES Profesores(id)
)
''')

# Insertar datos de ejemplo
profesores = [
    ('Juan Perez',),
    ('Ana Lopez',),
    ('Carlos Ruiz',),
    ('Maria Diaz',)
]
cursor.executemany("INSERT INTO Profesores (nombre) VALUES (?)", profesores)

# Insertar registros relacionados
cursos_materias = [
    (1, 101, 1),
    (2, 102, 1),
    (3, 103, 2),
    (4, 104, 3),
    (5, 105, 4)
]
cursor.executemany("INSERT INTO Cursos_Materias VALUES (?, ?, ?)", cursos_materias)

conn.commit()
conn.close()

print("Base de datos 'escuela.db' creada correctamente con tablas y datos de ejemplo.")
