# ejercicio210.py
import sqlite3

# Conectar a la base de datos creada previamente
conn = sqlite3.connect('poblacion.db')
cursor = conn.cursor()

# a) Cuántos nacimientos hubo en el mes de octubre
cursor.execute("SELECT COUNT(*) FROM Poblacion WHERE Mes = 10")
nac_octubre = cursor.fetchone()[0]
print(f"a) Nacimientos en octubre: {nac_octubre}")

# b) Cuántos nacimientos hubo antes del 9 de julio de 1970
cursor.execute("""
SELECT COUNT(*) FROM Poblacion
WHERE (Anio < 1970)
   OR (Anio = 1970 AND Mes < 7)
   OR (Anio = 1970 AND Mes = 7 AND Dia < 9)
""")
nac_antes_1970 = cursor.fetchone()[0]
print(f"b) Nacimientos antes del 9 de julio de 1970: {nac_antes_1970}")

# c) Cuántos nacimientos de mujeres hubo en la primavera de 1942
# Primavera: septiembre (9), octubre (10), noviembre (11)
cursor.execute("""
SELECT COUNT(*) FROM Poblacion
WHERE Sexo = 'F' AND Anio = 1942 AND Mes IN (9, 10, 11)
""")
nac_primavera = cursor.fetchone()[0]
print(f"c) Nacimientos de mujeres en la primavera de 1942: {nac_primavera}")

# d) Sexo y Nombre de la persona más anciana
cursor.execute("""
SELECT Sexo, Nombre, Dia, Mes, Anio FROM Poblacion
ORDER BY Anio ASC, Mes ASC, Dia ASC
LIMIT 1
""")
anciano = cursor.fetchone()
if anciano:
    sexo = 'Masculino' if anciano[0] == 'M' else 'Femenino'
    print(f"d) Persona más anciana: {anciano[1]} ({sexo}) "
          f"— Nacido/a el {anciano[2]:02d}/{anciano[3]:02d}/{anciano[4]}")
else:
    print("d) No hay datos en la tabla.")

conn.close()
