# script210.py
import sqlite3

# Crear base de datos SQLite
conn = sqlite3.connect('poblacion.db')
cursor = conn.cursor()

# Eliminar la tabla si ya existe
cursor.execute("DROP TABLE IF EXISTS Poblacion")

# Crear la tabla Poblacion
cursor.execute('''
CREATE TABLE Poblacion (
    DNI INTEGER PRIMARY KEY,
    Nombre TEXT NOT NULL,
    Dia INTEGER NOT NULL,
    Mes INTEGER NOT NULL,
    Anio INTEGER NOT NULL,
    Sexo TEXT CHECK(Sexo IN ('M', 'F')) NOT NULL
)
''')

conn.commit()
conn.close()

print("Base de datos 'poblacion.db' creada correctamente con la tabla 'Poblacion'.")
